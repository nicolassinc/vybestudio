import React, { createContext, useContext, useState, useEffect } from 'react';
import { storageService } from '../services/storageService';

interface AuthContextType {
  isAuthenticated: boolean;
  isDemoMode: boolean;
  login: (passcode: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    return storageService.isAdminAuthenticated();
  });

  const isDemoMode = true; // Flag identifying client-side prototype vs Firebase production

  useEffect(() => {
    storageService.setAdminAuthenticated(isAuthenticated);
  }, [isAuthenticated]);

  const login = async (passcode: string): Promise<{ success: boolean; error?: string }> => {
    // Simulação com validação explícita.
    // No modo de demonstração, qualquer senha não-vazia ou a senha de prévia 'vybe2026' ou 'admin' é aceita
    // com aviso transparente sobre a necessidade de Firebase Auth para produção.
    if (!passcode || passcode.trim().length === 0) {
      return { success: false, error: 'Por favor, digite uma chave de acesso.' };
    }

    // Aceita chave de demonstração padrão
    if (passcode.trim().toLowerCase() === 'vybe2026' || passcode.trim().toLowerCase() === 'admin' || passcode.trim().length >= 4) {
      setIsAuthenticated(true);
      return { success: true };
    }

    return { success: false, error: 'Credencial inválida para o modo de demonstração.' };
  };

  const logout = () => {
    setIsAuthenticated(false);
  };

  return (
    <AuthContext.Provider value={{ isAuthenticated, isDemoMode, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth deve ser utilizado dentro de um AuthProvider');
  }
  return context;
};
