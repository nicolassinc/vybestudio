import { storageService } from '../services/storageService';
import React, { createContext, useContext, useState, useEffect } from 'react';
import { CartItem, CustomizationData } from '../types';
import { saveArtworkToIndexedDB } from '../services/indexedDb';

interface CartContextType {
  cart: CartItem[];
  addToCart: (item: {
    productId: string;
    name: string;
    category: string;
    unitPrice: number;
    quantity: number;
    image: string;
    colorName?: string;
    sizeName?: string;
    customization?: CustomizationData;
  }) => Promise<string>;
  removeFromCart: (cartItemId: string) => void;
  updateQuantity: (cartItemId: string, quantity: number) => void;
  clearCart: () => void;
  totalItems: number;
  subtotal: number;
  isCartOpen: boolean;
  openCart: () => void;
  closeCart: () => void;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

const CART_STORAGE_KEY = 'vybe_cart_v1';

export const CartProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem(CART_STORAGE_KEY);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {
      console.warn('Erro ao carregar carrinho:', e);
    }
    return [];
  });

  const [isCartOpen, setIsCartOpen] = useState(false);

  // Persist cart to localStorage (without heavy blobs, storing only lightweight previews/metadata)
  useEffect(() => {
    try {
      // Clean up any heavy payload before saving to localStorage
      const safeItems = cart.map(item => {
        if (!item.customization) return item;
        // Ensure we don't store 10MB base64 in localStorage
        const safeCust = { ...item.customization };
        // We keep thumbnail preview if <= 200KB, otherwise rely on IndexedDB key
        return {
          ...item,
          customization: safeCust,
        };
      });
      localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(safeItems));
    } catch (e) {
      console.warn('Erro ao salvar carrinho no localStorage:', e);
    }
  }, [cart]);

  const buildSku = (productId: string, colorName?: string, sizeName?: string) => {
    const base = storageService.getProductById(productId)?.sku;
    if (!base) return undefined;
    const slug = (t?: string) => (t || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-zA-Z0-9]/g, '').toUpperCase();
    return [base, slug(colorName), slug(sizeName)].filter(Boolean).join('-');
  };

  const addToCart = async (item: {
    productId: string;
    name: string;
    category: string;
    unitPrice: number;
    quantity: number;
    image: string;
    colorName?: string;
    sizeName?: string;
    customization?: CustomizationData;
  }): Promise<string> => {
    // If it's a customized item, save artwork safely to IndexedDB if present
    if (item.customization && item.customization.artworkDataUrl) {
      try {
        await saveArtworkToIndexedDB({
          id: item.customization.customId,
          fileName: item.customization.originalFileName || 'arte-personalizada.png',
          fileType: 'image/png',
          fileSize: item.customization.originalFileSize || 0,
          dataUrl: item.customization.artworkDataUrl,
          createdAt: Date.now(),
        });
      } catch (err) {
        console.warn('IndexedDB save skipped/fallback:', err);
      }
    }

    const uniqueId = item.customization
      ? `cust-${item.customization.customId}`
      : `item-${item.productId}-${item.colorName || 'standard'}-${item.sizeName || 'un'}`;

    setCart(prevCart => {
      // If it's customized, ALWAYS keep as distinct item
      if (item.customization) {
        const newItem: CartItem = {
          id: uniqueId,
          productId: item.productId,
          name: item.name,
          category: item.category,
          unitPrice: item.unitPrice,
          quantity: item.quantity,
          image: item.image,
          colorName: item.colorName,
          sku: buildSku(item.productId, item.colorName),
          customization: item.customization,
          totalPrice: item.unitPrice * item.quantity,
        };
        return [...prevCart, newItem];
      }

      // For standard non-custom products, check if already in cart
      const existingIndex = prevCart.findIndex(
        ci => !ci.customization && ci.productId === item.productId && ci.colorName === item.colorName && ci.sizeName === item.sizeName
      );

      if (existingIndex > -1) {
        const updated = [...prevCart];
        const newQty = updated[existingIndex].quantity + item.quantity;
        updated[existingIndex] = {
          ...updated[existingIndex],
          quantity: newQty,
          totalPrice: updated[existingIndex].unitPrice * newQty,
        };
        return updated;
      }

      const newItem: CartItem = {
        id: uniqueId,
        productId: item.productId,
        name: item.name,
        category: item.category,
        unitPrice: item.unitPrice,
        quantity: item.quantity,
        image: item.image,
        colorName: item.colorName,
        sizeName: item.sizeName,
        sku: buildSku(item.productId, item.colorName, item.sizeName),
        totalPrice: item.unitPrice * item.quantity,
      };
      return [...prevCart, newItem];
    });

    setIsCartOpen(true);
    return uniqueId;
  };

  const removeFromCart = (cartItemId: string) => {
    setCart(prev => prev.filter(item => item.id !== cartItemId));
  };

  const updateQuantity = (cartItemId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(cartItemId);
      return;
    }
    setCart(prev =>
      prev.map(item => {
        if (item.id === cartItemId) {
          return {
            ...item,
            quantity,
            totalPrice: item.unitPrice * quantity,
          };
        }
        return item;
      })
    );
  };

  const clearCart = () => {
    setCart([]);
  };

  const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
  const subtotal = cart.reduce((sum, item) => sum + item.totalPrice, 0);

  return (
    <CartContext.Provider
      value={{
        cart,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        totalItems,
        subtotal,
        isCartOpen,
        openCart: () => setIsCartOpen(true),
        closeCart: () => setIsCartOpen(false),
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

export const useCart = (): CartContextType => {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart deve ser utilizado dentro de um CartProvider');
  }
  return context;
};
