export interface ProductColor {
  id: string;
  name: string;
  hex: string;
  inStock: boolean;
  imagePreviewUrl?: string;
}

export interface ProductSpecs {
  dimensions?: string; // e.g. "8 cm × 9,5 cm"
  diameter?: string;   // e.g. "8 cm"
  height?: string;     // e.g. "9,5 cm"
  printArea?: string;  // e.g. "21 cm × 9,5 cm"
  capacity?: string;   // e.g. "325 ml"
  material?: string;   // e.g. "Cerâmica Resinada Classe AAA"
  weight?: string;     // e.g. "330 g"
  colors?: ProductColor[];
  sizes?: string[];
}

export interface Product {
  id: string;
  sku?: string; // ex.: CAN-001
  name: string;
  slug: string;
  category: 'canecas' | 'camisas' | 'bags' | 'presentes';
  categoryLabel: string;
  description: string;
  price: number;
  minQuantity: number;
  images: string[];
  inStock: boolean;
  isCustomizable: boolean;
  isFeatured: boolean;
  specs: ProductSpecs;
  badgeText?: string;
}

export interface CustomizationData {
  customId: string;
  productId: string;
  productName: string;
  color: ProductColor;
  quantity: number;
  printWidthCm: number;
  printHeightCm: number;
  artworkKey?: string; // IndexedDB key
  artworkDataUrl?: string; // Preview data URL
  offsetX: number; // in percentage or pixels
  offsetY: number;
  scale: number;
  rotation: number;
  dpiEstimate: number;
  dpiRating: 'excelente' | 'boa' | 'baixa';
  mockupPreviewDataUrl?: string;
  originalFileName?: string;
  originalFileSize?: number;
}

export interface CartItem {
  id: string; // Unique cart item ID (customizations have their own unique ID)
  productId: string;
  name: string;
  category: string;
  unitPrice: number;
  quantity: number;
  image: string;
  colorName?: string;
  sizeName?: string;
  sku?: string; // SKU do produto + variação
  customization?: CustomizationData;
  totalPrice: number;
}

export interface CustomerDetails {
  name: string;
  whatsapp: string;
  email?: string;
  deliveryMethod: 'retirada' | 'entrega';
  address?: string;
  notes?: string;
}

export type OrderStatus = 'pendente' | 'em_producao' | 'concluido' | 'cancelado';

export interface Order {
  id: string; // e.g. #VYBE-2026-8492
  createdAt: string;
  customer: CustomerDetails;
  items: CartItem[];
  subtotal: number;
  total: number;
  status: OrderStatus;
  hasCustomArtwork: boolean;
}

export interface StoreSettings {
  storeName: string;
  slogan: string;
  whatsappNumber: string; // 5511999999999
  whatsappDisplay: string; // (11) 99999-9999
  email: string;
  instagram: string;
  pickupAddress: string;
  standardProductionTime: string;
  isDemoMode: boolean;
}

export interface CategoryInfo {
  id: 'canecas' | 'camisas' | 'bags' | 'presentes';
  name: string;
  tagline: string;
  image: string;
  productCount: number;
  customizable: boolean;
}
