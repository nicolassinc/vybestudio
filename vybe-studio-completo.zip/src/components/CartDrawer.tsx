import React from 'react';
import { useNavigate } from 'react-router-dom';
import { X, Trash2, Plus, Minus, ShoppingBag, ArrowRight, Wand2 } from 'lucide-react';
import { useCart } from '../context/CartContext';

export const CartDrawer: React.FC = () => {
  const { cart, isCartOpen, closeCart, removeFromCart, updateQuantity, subtotal, totalItems } = useCart();
  const navigate = useNavigate();

  if (!isCartOpen) return null;

  const formattedSubtotal = new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  }).format(subtotal);

  const handleCheckout = () => {
    closeCart();
    navigate('/checkout');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-stone-900/40 backdrop-blur-xs transition-opacity duration-300"
        onClick={closeCart}
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-white shadow-2xl flex flex-col">
          {/* Header */}
          <div className="flex items-center justify-between px-6 py-4 border-b border-stone-200">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-stone-800" />
              <h2 className="text-base font-bold text-stone-900">
                Seu Carrinho
              </h2>
              <span className="text-xs text-stone-500 font-mono">
                ({totalItems} {totalItems === 1 ? 'item' : 'itens'})
              </span>
            </div>
            <button
              type="button"
              onClick={closeCart}
              aria-label="Fechar carrinho"
              className="p-1.5 text-stone-400 hover:text-stone-700 hover:bg-stone-100 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Item List */}
          <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4 divide-y divide-stone-100">
            {cart.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center py-16">
                <div className="w-14 h-14 rounded-full bg-stone-100 flex items-center justify-center text-stone-400 mb-3">
                  <ShoppingBag className="w-6 h-6" />
                </div>
                <h3 className="text-sm font-semibold text-stone-800">Seu carrinho está vazio</h3>
                <p className="text-xs text-stone-500 max-w-xs mt-1 mb-5">
                  Explore nosso catálogo e personalize produtos com a sua vibe.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    closeCart();
                    navigate('/produtos');
                  }}
                  className="px-4 py-2 text-xs font-semibold text-white bg-black rounded-lg hover:bg-stone-800 transition-colors"
                >
                  Explorar Catálogo
                </button>
              </div>
            ) : (
              cart.map(item => (
                <div key={item.id} className="pt-4 first:pt-0 flex gap-4">
                  {/* Thumbnail */}
                  <div className="w-20 h-20 bg-stone-50 border border-stone-200 rounded-lg shrink-0 overflow-hidden flex items-center justify-center p-1.5 relative">
                    <img
                      src={
                        item.customization?.mockupPreviewDataUrl ||
                        item.customization?.artworkDataUrl ||
                        item.image
                      }
                      alt={item.name}
                      className="w-full h-full object-contain"
                    />
                    {item.customization && (
                      <span className="absolute bottom-1 right-1 bg-black/80 text-white text-[9px] px-1 rounded-xs font-mono">
                        2D
                      </span>
                    )}
                  </div>

                  {/* Info */}
                  <div className="flex-1 flex flex-col justify-between">
                    <div>
                      <div className="flex items-start justify-between gap-2">
                        <h4 className="text-sm font-semibold text-stone-900 leading-tight">
                          {item.name}
                        </h4>
                        <button
                          type="button"
                          onClick={() => removeFromCart(item.id)}
                          className="text-stone-400 hover:text-rose-600 p-0.5 transition-colors"
                          title="Remover do carrinho"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>

                      {/* Customization badge */}
                      {item.customization ? (
                        <div className="mt-1 space-y-0.5 text-xs text-stone-500">
                          <p className="flex items-center gap-1 text-[11px] font-medium text-stone-700">
                            <Wand2 className="w-3 h-3 text-stone-800" />
                            <span>Arte personalizada ({item.customization.printWidthCm}×{item.customization.printHeightCm}cm)</span>
                          </p>
                          <p className="text-[11px] text-stone-500">
                            Cor: {item.customization.color.name}
                          </p>
                        </div>
                      ) : (
                        item.colorName && (
                          <p className="text-[11px] text-stone-500 mt-0.5">Cor: {item.colorName}{item.sizeName ? ` · Tam: ${item.sizeName}` : ''}</p>
                        )
                      )}
                    </div>

                    {/* Quantity Stepper & Price */}
                    <div className="flex items-center justify-between pt-2 mt-2 border-t border-stone-50">
                      <div className="flex items-center border border-stone-200 rounded-md">
                        <button
                          type="button"
                          onClick={() => updateQuantity(item.id, item.quantity - 1)}
                          className="p-1 text-stone-500 hover:text-black hover:bg-stone-100 transition-colors"
                          aria-label="Diminuir quantidade"
                        >
                          <Minus className="w-3.5 h-3.5" />
                        </button>
                        <span className="px-2.5 text-xs font-semibold text-stone-800 font-mono">
                          {item.quantity}
                        </span>
                        <button
                          type="button"
                          onClick={() => updateQuantity(item.id, item.quantity + 1)}
                          className="p-1 text-stone-500 hover:text-black hover:bg-stone-100 transition-colors"
                          aria-label="Aumentar quantidade"
                        >
                          <Plus className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <span className="text-sm font-bold text-stone-900 font-mono tabular-nums">
                        {new Intl.NumberFormat('pt-BR', {
                          style: 'currency',
                          currency: 'BRL',
                        }).format(item.totalPrice)}
                      </span>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Footer Summary & Checkout CTA */}
          {cart.length > 0 && (
            <div className="p-6 border-t border-stone-200 bg-stone-50 space-y-4">
              <div className="space-y-1.5 text-sm">
                <div className="flex items-center justify-between text-stone-600">
                  <span>Subtotal</span>
                  <span className="font-mono tabular-nums font-semibold text-stone-900">
                    {formattedSubtotal}
                  </span>
                </div>
                <div className="flex items-center justify-between text-xs text-stone-500">
                  <span>Envio / Retirada</span>
                  <span>Calculado na finalização</span>
                </div>
              </div>

              <button
                type="button"
                onClick={handleCheckout}
                className="w-full flex items-center justify-center gap-2 py-3 px-4 bg-black text-white text-sm font-semibold rounded-xl hover:bg-stone-800 transition-colors shadow-sm"
              >
                <span>Finalizar Pedido</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={closeCart}
                className="w-full text-center text-xs font-medium text-stone-500 hover:text-stone-900 transition-colors py-1"
              >
                Continuar Comprando
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
