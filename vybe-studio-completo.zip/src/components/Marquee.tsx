import React from 'react';
import { storageService } from '../services/storageService';

const brl = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });

function getItems(): string[] {
  const settings = storageService.getSettings();
  const products = storageService.getProducts();
  const mugs = products.filter(p => p.category === 'canecas');
  const items: string[] = ['Caneca com prévia em tempo real antes de pedir'];

  if (mugs.length > 0) {
    items.push(`Canecas a partir de ${brl.format(Math.min(...mugs.map(p => p.price)))}`);
    const area = mugs[0].specs.printArea;
    if (area) items.push(`Área de impressão da caneca: ${area}`);
  }

  items.push('Camisas, bags e presentes personalizados');
  items.push(`Produção: ${settings.standardProductionTime}`);
  items.push('Retirada com agendamento ou entrega combinada');
  items.push('Pagamento e frete combinados pelo WhatsApp');
  return items;
}

const Track: React.FC<{ items: string[]; hidden?: boolean }> = ({ items, hidden }) => (
  <ul
    className={`flex shrink-0 items-center ${hidden ? 'vybe-marquee-dup' : ''}`}
    aria-hidden={hidden || undefined}
  >
    {items.map(item => (
      <li key={item} className="flex items-center whitespace-nowrap">
        <span className="text-sm font-medium text-ink sm:text-[15px]">{item}</span>
        <span className="mx-6 h-1 w-1 rounded-full bg-stone-400 sm:mx-10" aria-hidden="true" />
      </li>
    ))}
  </ul>
);

export const Marquee: React.FC = () => {
  const items = getItems();
  return (
    <div
      className="vybe-marquee overflow-hidden border-b border-stone-200 bg-snow py-3 [mask-image:linear-gradient(to_right,transparent,#000_6%,#000_94%,transparent)]"
      role="region"
      aria-label="Informações da loja"
    >
      <div className="vybe-marquee-track flex w-max">
        <Track items={items} />
        <Track items={items} hidden />
      </div>
    </div>
  );
};
