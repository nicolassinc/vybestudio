import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { ShoppingBag, Search, Shield, Menu, X } from 'lucide-react';
import { useCart } from '../context/CartContext';

interface NavbarProps {
  onOpenSearch: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenSearch }) => {
  const location = useLocation();
  const { totalItems, openCart } = useCart();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { name: 'Início', path: '/' },
    { name: 'Produtos', path: '/produtos' },
    { name: 'Personalizar', path: '/personalizar' },
    { name: 'Sobre', path: '/sobre' },
    { name: 'Contato', path: '/contato' },
  ];

  const isActive = (path: string) => {
    if (path === '/' && location.pathname === '/') return true;
    if (path !== '/' && location.pathname.startsWith(path)) return true;
    return false;
  };

  // Fechar menu ao mudar de rota
  useEffect(() => {
    setMobileMenuOpen(false);
  }, [location.pathname, location.search]);

  // Fechar menu ao pressionar Escape
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setMobileMenuOpen(false);
    };
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <header className="sticky top-0 z-50 bg-paper/90 backdrop-blur-md border-b border-stone-200/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative flex items-center justify-between h-16 sm:h-20 gap-3">
          {/* Zona 1: Botão das 3 Listras (lado esquerdo da logo) + Logo Oficial */}
          <div className="flex items-center gap-1.5 sm:gap-3 shrink-0">
            {/* As 3 listras originais, sem o nome menu */}
            <button
              type="button"
              onClick={() => setMobileMenuOpen(prev => !prev)}
              aria-expanded={mobileMenuOpen}
              aria-label={mobileMenuOpen ? "Fechar menu de navegação" : "Abrir menu de navegação"}
              className="inline-flex h-11 w-11 items-center justify-center text-stone-700 hover:text-black hover:bg-stone-100 rounded-lg cursor-pointer transition-colors"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>

          </div>

          {/* Logo oficial, centralizada no cabeçalho */}
          <Link
            to="/"
            className="absolute left-1/2 flex -translate-x-1/2 items-center py-1 transition-opacity hover:opacity-85"
            aria-label="VYBE Studio - Página Inicial"
          >
            <img
              src="/images/logo.png"
              alt="VYBE Studio"
              className="h-7 w-auto object-contain min-[400px]:h-8 sm:h-10 md:h-11"
              loading="eager"
            />
          </Link>

          {/* Zona 2: Links no desktop */}


          {/* Zona 3: Ações primárias (Busca, Admin, Carrinho) */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            {/* Busca */}
            <button
              type="button"
              onClick={onOpenSearch}
              aria-label="Buscar produtos"
              className="inline-flex h-11 w-11 items-center justify-center text-stone-700 hover:text-black hover:bg-stone-100 rounded-lg transition-colors cursor-pointer"
            >
              <Search className="w-5 h-5" />
            </button>

            {/* Carrinho */}
            <button
              type="button"
              onClick={openCart}
              aria-label="Carrinho de compras"
              className="flex min-h-11 items-center gap-2 px-3 py-2 text-stone-900 hover:bg-stone-100 rounded-lg transition-colors cursor-pointer"
            >
              <div className="relative">
                <ShoppingBag className="w-5 h-5" />
                {totalItems > 0 && (
                  <span className="absolute -top-1.5 -right-2 bg-black text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center font-mono">
                    {totalItems}
                  </span>
                )}
              </div>
              <span className="hidden sm:inline text-xs font-semibold uppercase tracking-wider">
                Carrinho
              </span>
            </button>
          </div>
        </div>
        <nav className="hidden lg:flex items-center justify-center gap-8 pb-3 text-sm font-medium text-stone-600">
            {navLinks.map(link => (
              <Link
                key={link.path}
                to={link.path}
                className={`transition-colors hover:text-[#111111] py-1 relative ${
                  isActive(link.path)
                    ? 'text-[#111111] font-semibold after:absolute after:bottom-0 after:left-0 after:w-full after:h-[2px] after:bg-[#111111]'
                    : 'text-stone-600'
                }`}
              >
                {link.name}
              </Link>
            ))}
          </nav>
      </div>

      {/* Menu / Drawer com as abas de produto, personalizar, etc. */}
      {mobileMenuOpen && (
        <div className="vybe-drop border-t border-stone-200 bg-snow px-4 pt-3 pb-6 space-y-3 shadow-lg max-h-[85vh] overflow-y-auto">
          {/* Abas Principais */}
          <div className="space-y-1">
            {navLinks.map(link => (
              <Link
                key={link.path}
                to={link.path}
                onClick={() => setMobileMenuOpen(false)}
                className={`block px-3 py-3.5 rounded-lg text-base font-medium transition-colors ${
                  isActive(link.path)
                    ? 'bg-stone-100 text-black font-semibold'
                    : 'text-stone-700 hover:bg-stone-50'
                }`}
              >
                {link.name}
              </Link>
            ))}
          </div>

          <div className="pt-3 border-t border-stone-100">
            <Link
              to="/admin"
              onClick={() => setMobileMenuOpen(false)}
              className="flex items-center gap-2 px-3 py-2.5 text-stone-600 hover:text-black text-sm"
            >
              <Shield className="w-4 h-4" />
              <span>Painel Administrativo</span>
            </Link>
          </div>
        </div>
      )}
    </header>
  );
};
