import React, { useState, useEffect } from 'react';
import {
  Star,
  Shield,
  Lock,
  LogOut,
  Package,
  Layers,
  ShoppingBag,
  Settings,
  Plus,
  Trash2,
  Edit2,
  Check,
  X,
  AlertTriangle,
  Info,
  ExternalLink,
  Wand2,
  Eye,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { storageService } from '../services/storageService';
import { Product, Order, StoreSettings, CategoryInfo } from '../types';
import { getArtworkFromIndexedDB } from '../services/indexedDb';

export const AdminPage: React.FC = () => {
  const { isAuthenticated, isDemoMode, login, logout } = useAuth();
  const [passcode, setPasscode] = useState('');
  const [loginError, setLoginError] = useState('');
  const [activeTab, setActiveTab] = useState<'products' | 'orders' | 'customization' | 'settings'>('products');

  // Products state
  const [products, setProducts] = useState<Product[]>([]);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [isAddingProduct, setIsAddingProduct] = useState(false);

  // Orders state
  const [orders, setOrders] = useState<Order[]>([]);
  const [selectedOrderForArtwork, setSelectedOrderForArtwork] = useState<Order | null>(null);
  const [orderArtworkPreview, setOrderArtworkPreview] = useState<string | null>(null);

  // Settings state
  const [settings, setSettings] = useState<StoreSettings>(storageService.getSettings());
  const [settingsSavedMessage, setSettingsSavedMessage] = useState(false);

  // Load data
  const refreshData = () => {
    setProducts(storageService.getProducts());
    setOrders(storageService.getOrders());
    setSettings(storageService.getSettings());
  };

  useEffect(() => {
    if (isAuthenticated) {
      refreshData();
    }
  }, [isAuthenticated]);

  // Handle Login
  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    const res = await login(passcode);
    if (!res.success) {
      setLoginError(res.error || 'Credencial inválida.');
    }
  };

  // Product CRUD
  const handleSaveProduct = (prod: Product) => {
    let updated: Product[];
    if (products.some(p => p.id === prod.id)) {
      updated = products.map(p => (p.id === prod.id ? prod : p));
    } else {
      updated = [...products, prod];
    }
    setProducts(updated);
    storageService.saveProducts(updated);
    setEditingProduct(null);
    setIsAddingProduct(false);
  };

  const handleDeleteProduct = (id: string) => {
    if (confirm('Tem certeza que deseja remover este produto?')) {
      const updated = products.filter(p => p.id !== id);
      setProducts(updated);
      storageService.saveProducts(updated);
    }
  };

  const handleToggleProductFeatured = (id: string) => {
    const updated = products.map(p => (p.id === id ? { ...p, isFeatured: !p.isFeatured } : p));
    setProducts(updated);
    storageService.saveProducts(updated);
  };

  const handleToggleProductStock = (id: string) => {
    const updated = products.map(p => (p.id === id ? { ...p, inStock: !p.inStock } : p));
    setProducts(updated);
    storageService.saveProducts(updated);
  };

  // Order Status update
  const handleUpdateOrderStatus = (orderId: string, status: Order['status']) => {
    storageService.updateOrderStatus(orderId, status);
    setOrders(storageService.getOrders());
  };

  // View custom artwork for an order
  const handleViewOrderArtwork = async (order: Order) => {
    setSelectedOrderForArtwork(order);
    const customItem = order.items.find(it => it.customization);
    if (customItem?.customization) {
      // First try to load full resolution from IndexedDB
      if (customItem.customization.customId) {
        const stored = await getArtworkFromIndexedDB(customItem.customization.customId);
        if (stored?.dataUrl) {
          setOrderArtworkPreview(stored.dataUrl);
          return;
        }
      }
      // Fallback to embedded snapshot preview
      setOrderArtworkPreview(customItem.customization.mockupPreviewDataUrl || customItem.customization.artworkDataUrl || null);
    } else {
      setOrderArtworkPreview(null);
    }
  };

  // Save Store Settings
  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    storageService.saveSettings(settings);
    setSettingsSavedMessage(true);
    setTimeout(() => setSettingsSavedMessage(false), 3000);
  };

  // ----------------------------------------------------
  // LOGIN SCREEN
  // ----------------------------------------------------
  if (!isAuthenticated) {
    return (
      <div className="min-h-[75vh] flex items-center justify-center px-4 py-16">
        <div className="w-full max-w-md bg-white rounded-2xl border border-stone-200 p-8 shadow-xl space-y-6">
          <div className="text-center space-y-3">
            <img
              src="/images/logo.png"
              alt="VYBE Studio"
              className="h-11 sm:h-12 w-auto mx-auto max-w-[220px] object-contain"
            />
            <div className="w-10 h-10 rounded-xl bg-black text-white flex items-center justify-center mx-auto shadow-xs">
              <Shield className="w-5 h-5" />
            </div>
            <h1 className="font-display text-2xl font-bold text-stone-900">
              Painel Administrativo
            </h1>
            <p className="text-xs text-stone-500">
              Acesso restrito à gestão de catálogo, pedidos e personalizações da VYBE Studio.
            </p>
          </div>

          {/* Security Transparency Notice */}
          <div className="p-3.5 bg-amber-50/80 border border-amber-200 rounded-xl text-xs text-amber-900 space-y-1">
            <div className="flex items-center gap-1.5 font-semibold">
              <Info className="w-4 h-4 text-amber-700 shrink-0" />
              <span>Modo Demonstração (Pré-visualização)</span>
            </div>
            <p className="text-[11px] leading-relaxed text-amber-800">
              Em conformidade com as diretrizes do projeto, credenciais de produção não são gravadas no código do frontend. Digite qualquer chave de acesso (ex: <strong>vybe2026</strong> ou <strong>admin</strong>) para desbloquear a interface administrativa.
            </p>
          </div>

          <form onSubmit={handleLoginSubmit} className="space-y-4">
            <div>
              <label className="text-xs font-semibold text-stone-700 block mb-1">
                Chave de Acesso Administrativo
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="password"
                  value={passcode}
                  onChange={e => setPasscode(e.target.value)}
                  placeholder="Digite sua chave..."
                  autoFocus
                  className="w-full pl-9 pr-3 py-2.5 text-sm bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:border-black focus:bg-white transition-colors"
                />
              </div>
              {loginError && (
                <p className="text-xs text-rose-600 mt-1">{loginError}</p>
              )}
            </div>

            <button
              type="submit"
              className="w-full py-3 px-4 bg-black text-white text-xs font-bold uppercase tracking-wider rounded-xl hover:bg-stone-800 transition-colors shadow-xs"
            >
              Acessar Painel
            </button>
          </form>
        </div>
      </div>
    );
  }

  // ----------------------------------------------------
  // ADMIN DASHBOARD
  // ----------------------------------------------------
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 pb-24 space-y-8">
      {/* Top Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-stone-200 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="font-display text-2xl sm:text-3xl font-bold text-stone-900">
              Painel de Gestão VYBE Studio
            </h1>
            <span className="text-[10px] font-bold uppercase bg-stone-100 text-stone-700 border border-stone-200 px-2 py-0.5 rounded-sm">
              Demonstração Ativa
            </span>
          </div>
          <p className="text-xs text-stone-500 mt-1">
            Gerencie catálogo, pedidos recebidos, personalizações e configurações comerciais da loja.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={logout}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-200 rounded-lg transition-colors"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Sair do Painel</span>
          </button>
        </div>
      </div>

      {/* Persistence and Security Notice */}
      <div className="p-4 bg-stone-100 rounded-xl border border-stone-200 text-xs text-stone-700 space-y-1">
        <p className="font-semibold text-stone-900 flex items-center gap-1.5">
          <Shield className="w-4 h-4 text-stone-800" />
          Aviso sobre Persistência & Produção
        </p>
        <p className="leading-relaxed">
          Os dados abaixo estão armazenados localmente no navegador (LocalStorage + IndexedDB). Para uma loja pública definitiva com múltiplos clientes e administradores simultâneos, este painel está estruturado para receber conexão direta com banco de dados centralizado (ex: Firebase Firestore e Firebase Auth).
        </p>
      </div>

      {/* Tabs Navigation */}
      <div className="flex items-center gap-2 border-b border-stone-200 pb-2">
        <button
          type="button"
          onClick={() => setActiveTab('products')}
          className={`flex items-center gap-2 px-4 py-2 text-xs font-bold rounded-lg transition-colors ${
            activeTab === 'products'
              ? 'bg-black text-white shadow-xs'
              : 'text-stone-600 hover:text-black hover:bg-stone-100'
          }`}
        >
          <Package className="w-4 h-4" />
          <span>Produtos ({products.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('orders')}
          className={`flex items-center gap-2 px-4 py-2 text-xs font-bold rounded-lg transition-colors ${
            activeTab === 'orders'
              ? 'bg-black text-white shadow-xs'
              : 'text-stone-600 hover:text-black hover:bg-stone-100'
          }`}
        >
          <ShoppingBag className="w-4 h-4" />
          <span>Pedidos ({orders.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('customization')}
          className={`flex items-center gap-2 px-4 py-2 text-xs font-bold rounded-lg transition-colors ${
            activeTab === 'customization'
              ? 'bg-black text-white shadow-xs'
              : 'text-stone-600 hover:text-black hover:bg-stone-100'
          }`}
        >
          <Wand2 className="w-4 h-4" />
          <span>Personalização (Caneca 2D)</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('settings')}
          className={`flex items-center gap-2 px-4 py-2 text-xs font-bold rounded-lg transition-colors ${
            activeTab === 'settings'
              ? 'bg-black text-white shadow-xs'
              : 'text-stone-600 hover:text-black hover:bg-stone-100'
          }`}
        >
          <Settings className="w-4 h-4" />
          <span>Configurações & WhatsApp</span>
        </button>
      </div>

      {/* TAB 1: PRODUCTS */}
      {activeTab === 'products' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-stone-900">
              Produtos Cadastrados
            </h2>
            <button
              type="button"
              onClick={() => {
                const newP: Product = {
                  id: `prod-${Date.now()}`,
                  name: 'Novo Produto',
                  slug: `novo-produto-${Date.now()}`,
                  category: 'canecas',
                  categoryLabel: 'Canecas',
                  description: 'Descrição do novo produto...',
                  price: 49.90,
                  minQuantity: 1,
                  images: ['/images/mug_white_product.png'],
                  inStock: true,
                  isCustomizable: false,
                  isFeatured: false,
                  specs: { dimensions: 'Dimensões padrão' },
                };
                setEditingProduct(newP);
                setIsAddingProduct(true);
              }}
              className="inline-flex items-center gap-1.5 px-3 py-2 bg-black text-white text-xs font-semibold rounded-lg hover:bg-stone-800 transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span>Cadastrar Novo Produto</span>
            </button>
          </div>

          {/* Product Edit Modal if active */}
          {editingProduct && (
            <div className="p-6 bg-stone-50 rounded-2xl border border-stone-300 space-y-4">
              <div className="flex items-center justify-between border-b border-stone-200 pb-3">
                <h3 className="text-sm font-bold text-stone-900">
                  {isAddingProduct ? 'Novo Produto' : `Editar: ${editingProduct.name}`}
                </h3>
                <button
                  type="button"
                  onClick={() => setEditingProduct(null)}
                  className="p-1 text-stone-400 hover:text-stone-700"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div>
                  <label className="font-semibold text-stone-700 block mb-1">Nome do Produto</label>
                  <input
                    type="text"
                    value={editingProduct.name}
                    onChange={e => setEditingProduct({ ...editingProduct, name: e.target.value })}
                    className="w-full px-3 py-2 bg-white border border-stone-200 rounded-lg"
                  />
                </div>

                <div>
                  <label className="font-semibold text-stone-700 block mb-1">Preço Oficial (R$)</label>
                  <input
                    type="number"
                    step="0.10"
                    value={editingProduct.price}
                    onChange={e => setEditingProduct({ ...editingProduct, price: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-2 bg-white border border-stone-200 rounded-lg"
                  />
                </div>

                <div>
                  <label className="font-semibold text-stone-700 block mb-1">Categoria</label>
                  <select
                    value={editingProduct.category}
                    onChange={e => {
                      const cat = e.target.value as any;
                      const labels: any = { canecas: 'Canecas', camisas: 'Camisas', bags: 'Bags', presentes: 'Presentes' };
                      setEditingProduct({ ...editingProduct, category: cat, categoryLabel: labels[cat] });
                    }}
                    className="w-full px-3 py-2 bg-white border border-stone-200 rounded-lg"
                  >
                    <option value="canecas">Canecas</option>
                    <option value="camisas">Camisas</option>
                    <option value="bags">Bags</option>
                    <option value="presentes">Presentes</option>
                  </select>
                </div>

                <div>
                  <label className="font-semibold text-stone-700 block mb-1">URL Imagem Principal</label>
                  <input
                    type="text"
                    value={editingProduct.images[0] || ''}
                    onChange={e => setEditingProduct({ ...editingProduct, images: [e.target.value, ...editingProduct.images.slice(1)] })}
                    className="w-full px-3 py-2 bg-white border border-stone-200 rounded-lg"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="font-semibold text-stone-700 block mb-1">Descrição Comercial</label>
                  <textarea
                    rows={2}
                    value={editingProduct.description}
                    onChange={e => setEditingProduct({ ...editingProduct, description: e.target.value })}
                    className="w-full px-3 py-2 bg-white border border-stone-200 rounded-lg"
                  />
                </div>

                <div className="flex items-center gap-6 sm:col-span-2 pt-2">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={editingProduct.inStock}
                      onChange={e => setEditingProduct({ ...editingProduct, inStock: e.target.checked })}
                      className="rounded-sm"
                    />
                    <span className="font-semibold">Disponível em Estoque</span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={editingProduct.isCustomizable}
                      onChange={e => setEditingProduct({ ...editingProduct, isCustomizable: e.target.checked })}
                      className="rounded-sm"
                    />
                    <span className="font-semibold">Habilitar Personalizador 2D</span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={editingProduct.isFeatured}
                      onChange={e => setEditingProduct({ ...editingProduct, isFeatured: e.target.checked })}
                      className="rounded-sm"
                    />
                    <span className="font-semibold">Destacar na Home</span>
                  </label>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-stone-200">
                <button
                  type="button"
                  onClick={() => setEditingProduct(null)}
                  className="px-3 py-1.5 text-xs text-stone-600 hover:text-black"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  onClick={() => handleSaveProduct(editingProduct)}
                  className="px-4 py-1.5 bg-black text-white text-xs font-semibold rounded-lg hover:bg-stone-800"
                >
                  Salvar Alterações
                </button>
              </div>
            </div>
          )}

          {/* Products Table */}
          <div className="bg-white rounded-xl border border-stone-200 overflow-hidden shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-stone-50 border-b border-stone-200 text-stone-500 font-semibold uppercase tracking-wider">
                  <tr>
                    <th className="p-3">Produto</th>
                    <th className="p-3">Categoria</th>
                    <th className="p-3">Preço</th>
                    <th className="p-3">Estoque</th>
                    <th className="p-3">Personalizador</th>
                    <th className="p-3 text-right">Ações</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {products.map(prod => (
                    <tr key={prod.id} className="hover:bg-stone-50/70">
                      <td className="p-3 flex items-center gap-3">
                        <div className="w-10 h-10 rounded-md bg-stone-100 overflow-hidden p-1 shrink-0 flex items-center justify-center">
                          <img src={prod.images[0]} alt="" className="w-full h-full object-contain" />
                        </div>
                        <span className="font-semibold text-stone-900">{prod.name}
                          <span className="block font-mono text-[11px] text-stone-400">SKU {prod.sku}</span></span>
                      </td>
                      <td className="p-3 text-stone-600">{prod.categoryLabel}</td>
                      <td className="p-3 font-mono font-semibold text-stone-900">
                        {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(prod.price)}
                      </td>
                      <td className="p-3">
                        <button
                          type="button"
                          onClick={() => handleToggleProductStock(prod.id)}
                          className={`px-2 py-0.5 rounded-sm font-semibold text-[11px] ${
                            prod.inStock
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                              : 'bg-rose-50 text-rose-700 border border-rose-200'
                          }`}
                        >
                          {prod.inStock ? 'Disponível' : 'Esgotado'}
                        </button>
                      </td>
                      <td className="p-3">
                        {prod.isCustomizable ? (
                          <span className="text-emerald-700 font-semibold flex items-center gap-1">
                            <Check className="w-3.5 h-3.5" /> Ativo
                          </span>
                        ) : (
                          <span className="text-stone-400">Padrão</span>
                        )}
                      </td>
                      <td className="p-3 text-right space-x-2">
                        <button
                          type="button"
                          onClick={() => handleToggleProductFeatured(prod.id)}
                          aria-pressed={prod.isFeatured}
                          className={`p-1 ${prod.isFeatured ? 'text-amber-500' : 'text-stone-300 hover:text-stone-500'}`}
                          title={prod.isFeatured ? 'Remover destaque da Home' : 'Destacar na Home'}
                        >
                          <Star className="w-3.5 h-3.5" fill={prod.isFeatured ? 'currentColor' : 'none'} />
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setEditingProduct(prod);
                            setIsAddingProduct(false);
                          }}
                          className="p-1 text-stone-600 hover:text-black"
                          title="Editar"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeleteProduct(prod.id)}
                          className="p-1 text-stone-400 hover:text-rose-600"
                          title="Excluir"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: ORDERS */}
      {activeTab === 'orders' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-stone-900">
                Pedidos Registrados no Sistema
              </h2>
              <p className="text-xs text-stone-500">
                Pedidos originados pela loja com especificações e artes dos clientes.
              </p>
            </div>
          </div>

          {orders.length === 0 ? (
            <div className="py-16 text-center bg-white rounded-xl border border-stone-200">
              <ShoppingBag className="w-8 h-8 text-stone-400 mx-auto mb-2" />
              <p className="text-sm font-semibold text-stone-800">Nenhum pedido registrado ainda</p>
              <p className="text-xs text-stone-500 mt-1">
                Quando um cliente finalizar um pedido, ele aparecerá nesta lista com todos os detalhes e arte.
              </p>
            </div>
          ) : (
            <div className="bg-white rounded-xl border border-stone-200 overflow-hidden shadow-xs">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-stone-50 border-b border-stone-200 text-stone-500 font-semibold uppercase tracking-wider">
                    <tr>
                      <th className="p-3">ID Pedido</th>
                      <th className="p-3">Data</th>
                      <th className="p-3">Cliente</th>
                      <th className="p-3">WhatsApp</th>
                      <th className="p-3">Itens</th>
                      <th className="p-3">Total</th>
                      <th className="p-3">Status</th>
                      <th className="p-3 text-right">Arte</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100">
                    {orders.map(ord => (
                      <tr key={ord.id} className="hover:bg-stone-50/70">
                        <td className="p-3 font-mono font-bold text-stone-900">#{ord.id}</td>
                        <td className="p-3 text-stone-500">
                          {new Date(ord.createdAt).toLocaleDateString('pt-BR')}
                        </td>
                        <td className="p-3 font-medium text-stone-900">{ord.customer.name}</td>
                        <td className="p-3 font-mono text-stone-600">
                          <a
                            href={`https://wa.me/${ord.customer.whatsapp.replace(/\D/g, '')}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="hover:underline text-black"
                          >
                            {ord.customer.whatsapp}
                          </a>
                        </td>
                        <td className="p-3 text-stone-600">
                          {ord.items.map(it => `${it.quantity}x ${it.name}`).join(', ')}
                        </td>
                        <td className="p-3 font-mono font-semibold text-stone-900">
                          {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(ord.total)}
                        </td>
                        <td className="p-3">
                          <select
                            value={ord.status}
                            onChange={e => handleUpdateOrderStatus(ord.id, e.target.value as any)}
                            className="text-xs bg-stone-50 border border-stone-200 rounded-md px-2 py-1 font-medium"
                          >
                            <option value="pendente">Pendente</option>
                            <option value="em_producao">Em Produção</option>
                            <option value="concluido">Concluído</option>
                            <option value="cancelado">Cancelado</option>
                          </select>
                        </td>
                        <td className="p-3 text-right">
                          {ord.hasCustomArtwork ? (
                            <button
                              type="button"
                              onClick={() => handleViewOrderArtwork(ord)}
                              className="inline-flex items-center gap-1 px-2.5 py-1 bg-stone-100 hover:bg-black hover:text-white rounded-md text-stone-700 transition-colors"
                            >
                              <Eye className="w-3.5 h-3.5" />
                              <span>Ver Arte</span>
                            </button>
                          ) : (
                            <span className="text-stone-400">Padrão</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Artwork Modal */}
          {selectedOrderForArtwork && (
            <div className="fixed inset-0 z-50 bg-stone-900/50 backdrop-blur-xs flex items-center justify-center p-4">
              <div className="bg-white rounded-2xl max-w-xl w-full p-6 space-y-4 shadow-2xl">
                <div className="flex items-center justify-between border-b border-stone-200 pb-3">
                  <div>
                    <h3 className="text-sm font-bold text-stone-900">
                      Arte do Pedido #{selectedOrderForArtwork.id}
                    </h3>
                    <p className="text-xs text-stone-500">
                      Cliente: {selectedOrderForArtwork.customer.name}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setSelectedOrderForArtwork(null)}
                    className="p-1 text-stone-400 hover:text-stone-700"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="bg-stone-50 border border-stone-200 rounded-xl p-4 flex items-center justify-center min-h-[220px]">
                  {orderArtworkPreview ? (
                    <img
                      src={orderArtworkPreview}
                      alt="Arte do cliente"
                      className="max-h-72 max-w-full object-contain rounded-lg shadow-sm"
                    />
                  ) : (
                    <p className="text-xs text-stone-400">Arte não encontrada no armazenamento local.</p>
                  )}
                </div>

                <div className="flex justify-between items-center pt-2 text-xs">
                  <span className="text-stone-500">Área de gabarito: 21 × 9,5 cm</span>
                  {orderArtworkPreview && (
                    <a
                      href={orderArtworkPreview}
                      download={`arte-pedido-${selectedOrderForArtwork.id}.png`}
                      className="px-3 py-1.5 bg-black text-white rounded-lg font-semibold hover:bg-stone-800"
                    >
                      Baixar Imagem
                    </a>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 3: CUSTOMIZATION SETTINGS */}
      {activeTab === 'customization' && (
        <div className="bg-white rounded-xl border border-stone-200 p-6 space-y-6">
          <div>
            <h2 className="text-base font-bold text-stone-900">
              Configuração Técnica do Personalizador 2D
            </h2>
            <p className="text-xs text-stone-500 mt-0.5">
              Parâmetros físicos e de impressão da Caneca Cerâmica 325ml.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 text-xs">
            <div className="p-4 bg-stone-50 rounded-xl border border-stone-200 space-y-2">
              <h4 className="font-bold text-stone-900">Dimensões Físicas Oficiais</h4>
              <p>· Diâmetro: <strong>8 cm</strong></p>
              <p>· Altura: <strong>9,5 cm</strong></p>
              <p>· Capacidade: <strong>325 ml</strong></p>
              <p>· Imagem de Gabarito: <span className="font-mono text-stone-500">/images/mug_dimensions.png</span></p>
            </div>

            <div className="p-4 bg-stone-50 rounded-xl border border-stone-200 space-y-2">
              <h4 className="font-bold text-stone-900">Área de Impressão Sublimática</h4>
              <p>· Largura: <strong>21 cm</strong></p>
              <p>· Altura: <strong>9,5 cm</strong></p>
              <p>· Proporção: <strong>21 : 9.5 (~2.21:1)</strong></p>
              <p>· Mockup Fotográfico: <span className="font-mono text-stone-500">/images/mug_mockup.png</span></p>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: SETTINGS */}
      {activeTab === 'settings' && (
        <form onSubmit={handleSaveSettings} className="bg-white rounded-xl border border-stone-200 p-6 space-y-6">
          <div>
            <h2 className="text-base font-bold text-stone-900">
              Informações Comerciais da Loja & WhatsApp
            </h2>
            <p className="text-xs text-stone-500 mt-0.5">
              Configure o número oficial para onde os pedidos serão enviados.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="font-semibold text-stone-700 block mb-1">
                Nome da Loja
              </label>
              <input
                type="text"
                value={settings.storeName}
                onChange={e => setSettings({ ...settings, storeName: e.target.value })}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg focus:outline-none focus:border-black"
              />
            </div>

            <div>
              <label className="font-semibold text-stone-700 block mb-1">
                Slogan Oficial
              </label>
              <input
                type="text"
                value={settings.slogan}
                onChange={e => setSettings({ ...settings, slogan: e.target.value })}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg focus:outline-none focus:border-black"
              />
            </div>

            <div>
              <label className="font-semibold text-stone-700 block mb-1">
                WhatsApp Internacional (DDI + DDD + Número) *
              </label>
              <input
                type="text"
                value={settings.whatsappNumber}
                onChange={e => setSettings({ ...settings, whatsappNumber: e.target.value })}
                placeholder="Ex: 5511987654321"
                className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg focus:outline-none focus:border-black font-mono"
              />
              <span className="text-[11px] text-stone-400 mt-0.5 block">
                Utilizado para o link gerado wa.me/numero
              </span>
            </div>

            <div>
              <label className="font-semibold text-stone-700 block mb-1">
                WhatsApp Formatado (Exibição Visual)
              </label>
              <input
                type="text"
                value={settings.whatsappDisplay}
                onChange={e => setSettings({ ...settings, whatsappDisplay: e.target.value })}
                placeholder="Ex: (11) 98765-4321"
                className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg focus:outline-none focus:border-black font-mono"
              />
            </div>

            <div>
              <label className="font-semibold text-stone-700 block mb-1">
                E-mail de Atendimento
              </label>
              <input
                type="email"
                value={settings.email}
                onChange={e => setSettings({ ...settings, email: e.target.value })}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg focus:outline-none focus:border-black"
              />
            </div>

            <div>
              <label className="font-semibold text-stone-700 block mb-1">
                Instagram Oficial
              </label>
              <input
                type="text"
                value={settings.instagram}
                onChange={e => setSettings({ ...settings, instagram: e.target.value })}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg focus:outline-none focus:border-black"
              />
            </div>
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-stone-200">
            {settingsSavedMessage ? (
              <span className="text-xs font-semibold text-emerald-700 flex items-center gap-1">
                <Check className="w-4 h-4" /> Configurações salvas com sucesso!
              </span>
            ) : <span />}

            <button
              type="submit"
              className="px-5 py-2.5 bg-black text-white text-xs font-bold rounded-xl hover:bg-stone-800 transition-colors shadow-xs"
            >
              Salvar Configurações
            </button>
          </div>
        </form>
      )}
    </div>
  );
};
